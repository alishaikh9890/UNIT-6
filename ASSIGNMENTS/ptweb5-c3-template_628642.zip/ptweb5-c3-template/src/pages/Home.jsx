import React from "react";

const Home = () => {
  return <div>{/* Code here */}</div>;
};

export default Home;
